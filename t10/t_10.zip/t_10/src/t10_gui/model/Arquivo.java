package t10_gui.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Arquivo {
    private static int i=0;
    
    public static ArrayList<String> leitor(String path) throws IOException{
        ArrayList<String> resposta = new ArrayList<String>();
        BufferedReader buffRead = new BufferedReader(new FileReader(path));
        String linha = "";
        while(true){
            if(linha != null){
                resposta.add(linha);
            }else
                break;
            linha = buffRead.readLine();
    }
        buffRead.close();
        return resposta;
}
    
    public static void escritor(String path, String linha) throws IOException{
        BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path));   
        buffWrite.write(linha+"\n");
        buffWrite.close();  
    }
}
