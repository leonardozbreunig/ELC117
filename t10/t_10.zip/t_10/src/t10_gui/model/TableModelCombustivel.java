package t10_gui.model;


import java.io.IOException;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class TableModelCombustivel extends AbstractTableModel {
    private static final String caminho = "combustivel.txt";
    private static final String[] columnNames = {"Data", "Combustivel", "Preço"};

    private ArrayList<Posto> posto;
    private final int index;

   
    public TableModelCombustivel(int index, ArrayList<Posto> Posto) {
        this.index = index;
        this.posto = posto;
    }

    public void remove(int index, int i) {
        posto.get(index).getCombustivel().remove(i);
	fireTableRowsDeleted(index, i);
    }

    public Combustivel select(int index, int i) {
        return posto.get(index).getCombustivel().get(i);
    }
    
    public void add(int index, Combustivel c) throws IOException {
        posto.get(index).AddCombustivel(c);
        fireTableRowsInserted(posto.get(index).getCombustivel().size()-1, posto.get(index).getCombustivel().size()-1);
        Arquivo.escritor(caminho,c.getComb()+"..."+c.getData()+"..."+c.getPreço());
    }

    public void update(int index,int i, Combustivel c) {
        posto.get(index).getCombustivel().get(i).setData(c.getData());
        posto.get(index).getCombustivel().get(i).setPreço(c.getPreço());
        posto.get(index).getCombustivel().get(i).setComb(c.getComb());
        fireTableRowsUpdated(i, i);
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }

    @Override
    public int getRowCount() {
        return posto.get(index).getCombustivel().size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex) {
            case 0: return posto.get(index).getCombustivel().get(rowIndex).getComb();
            case 1: return posto.get(index).getCombustivel().get(rowIndex).getPreço();
            case 2: return posto.get(index).getCombustivel().get(rowIndex).getData();
        }            
        return null;
    }

}

