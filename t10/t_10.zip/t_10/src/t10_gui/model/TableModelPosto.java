package t10_gui.model;


import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class TableModelPosto extends AbstractTableModel {

    private static final String[] columnNames = {"CNPJ", "Razao Social", "Nome Fantasia", "Bandeira", "Rua" ,"Numero", "Bairro", "Cep"};

    private ArrayList<Posto> posto;

    public TableModelPosto() {
        posto = new ArrayList<Posto>();
    }

    public void remove(int index) {
	posto.remove(index);
	fireTableRowsDeleted(index, index);
    }

    public Posto select(int index) {
        return posto.get(index);
    }
    
    public void add(Posto p) {
        // Adds the element in the last position in the list
        posto.add(p);
        fireTableRowsInserted(posto.size()-1, posto.size()-1);
    }

    public void update(int index, Posto p) {
        posto.set(index, p);
        fireTableRowsUpdated(index, index);
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }

    @Override
    public int getRowCount() {
        return posto.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex) {
            case 0: return posto.get(rowIndex).getCnpj();
            case 1: return posto.get(rowIndex).getRazao_social();
            case 2: return posto.get(rowIndex).getNome_fantasia();
            case 3: return posto.get(rowIndex).getBandeira();
            case 4: return posto.get(rowIndex).getRua();
            case 5: return posto.get(rowIndex).getNumero();
            case 6: return posto.get(rowIndex).getBairro();
            case 7: return posto.get(rowIndex).getCep();
        }            
        return null;
    }

    public ArrayList<Posto> getPostoArray() {
        return posto;
    }

}

