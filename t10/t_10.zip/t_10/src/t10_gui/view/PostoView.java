package t10_gui.view;

import t10_gui.controller.PostoController;
import t10_gui.model.Posto;
import t10_gui.model.TableModelPosto;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


public class PostoView extends javax.swing.JFrame {

    private TableModelPosto tableModelPosto;
    private PostoController controller;

    /** Creates new form DisciplinaView */
    public PostoView() {
        initComponents();
        tableModelPosto = new TableModelPosto();
        tablePosto.setModel(tableModelPosto);
        controller = new PostoController(this, tableModelPosto);
    }

    public JTable getTablePosto() {
        return tablePosto;
    }

    public JTextField getTextCnpj() {
        return textCnpj;
    }

    public JTextField getTextNome() {
        return textNome;
    }
    
   public JTextField getTextRazaoSocial() {
        return textRazaoSocial;
    }
    public JTextField getTextBandeira() {
        return textBandeira;
    }
    
       public JTextField getTextRua() {
        return textRua;
    }
       
    public JTextField getTextNumero() {
        return textNumero;
    }
    
    public JTextField getTextCep() {
        return textCep;
    }
    
    public JTextField getTextBairro() {
        return textBairro;
    }
    
    public JTextField getTextImagem() {
        return textImagem;
    }

    public void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollpaneTable = new javax.swing.JScrollPane();
        tablePosto = new javax.swing.JTable();
        labelNome = new javax.swing.JLabel();
        textNome = new javax.swing.JTextField();
        labelNota = new javax.swing.JLabel();
        textBandeira = new javax.swing.JTextField();
        buttonLimpar = new javax.swing.JButton();
        buttonRemover = new javax.swing.JButton();
        buttonInserir = new javax.swing.JButton();
        labelAno = new javax.swing.JLabel();
        labelSemestre = new javax.swing.JLabel();
        buttonAlterar = new javax.swing.JButton();
        textCnpj = new javax.swing.JTextField();
        textRazaoSocial = new javax.swing.JTextField();
        labelNota1 = new javax.swing.JLabel();
        textRua = new javax.swing.JTextField();
        labelNota2 = new javax.swing.JLabel();
        textNumero = new javax.swing.JTextField();
        labelNota3 = new javax.swing.JLabel();
        textCep = new javax.swing.JTextField();
        LabelImage = new javax.swing.JLabel();
        labelNota4 = new javax.swing.JLabel();
        textBairro = new javax.swing.JTextField();
        buttonComb = new javax.swing.JButton();
        labelNota5 = new javax.swing.JLabel();
        textImagem = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tablePosto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tablePosto.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablePosto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablePostoMouseClicked(evt);
            }
        });
        scrollpaneTable.setViewportView(tablePosto);

        labelNome.setText("Nome Fantasia");

        labelNota.setText("Bandeira");

        buttonLimpar.setText("Limpar");
        buttonLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLimparActionPerformed(evt);
            }
        });

        buttonRemover.setText("Remover");
        buttonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonRemoverActionPerformed(evt);
            }
        });

        buttonInserir.setText("Inserir");
        buttonInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonInserirActionPerformed(evt);
            }
        });

        labelAno.setText("CNPJ");

        labelSemestre.setText("Razão Social");

        buttonAlterar.setText("Alterar");
        buttonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAlterarActionPerformed(evt);
            }
        });

        labelNota1.setText("Rua");

        labelNota2.setText("Numero");

        labelNota3.setText("Cep");

        LabelImage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        labelNota4.setText("Bairro");

        buttonComb.setText("Combustivel");
        buttonComb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCombActionPerformed(evt);
            }
        });

        labelNota5.setText("Imagem");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollpaneTable)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelNota2)
                                    .addComponent(labelNota3))
                                .addGap(38, 38, 38)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textCep)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(buttonLimpar)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(buttonAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(buttonRemover)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(buttonInserir))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(textNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(labelNota4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textBairro)))
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelSemestre)
                                    .addComponent(labelNome)
                                    .addComponent(labelAno)
                                    .addComponent(labelNota)
                                    .addComponent(labelNota1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textRua)
                                    .addComponent(textRazaoSocial)
                                    .addComponent(textNome, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textCnpj, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textBandeira))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelImage, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonComb)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelNota5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textImagem)))))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {buttonAlterar, buttonInserir, buttonLimpar, buttonRemover});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelAno)
                            .addComponent(textCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelSemestre)
                            .addComponent(textRazaoSocial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelNome))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelNota)
                            .addComponent(textBandeira, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelNota1)
                            .addComponent(textRua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelNota2)
                            .addComponent(textNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelNota4)
                            .addComponent(textBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(LabelImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNota3)
                    .addComponent(textCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelNota5)
                    .addComponent(textImagem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonLimpar)
                    .addComponent(buttonAlterar)
                    .addComponent(buttonRemover)
                    .addComponent(buttonInserir)
                    .addComponent(buttonComb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(scrollpaneTable, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonRemoverActionPerformed
        controller.remove();
    }//GEN-LAST:event_buttonRemoverActionPerformed
    
    private void buttonInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonInserirActionPerformed
        controller.insert();
    }//GEN-LAST:event_buttonInserirActionPerformed

    private void buttonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAlterarActionPerformed
        controller.update();
    }//GEN-LAST:event_buttonAlterarActionPerformed

    private void buttonLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLimparActionPerformed
        controller.clear();
    }//GEN-LAST:event_buttonLimparActionPerformed

    private void tablePostoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablePostoMouseClicked
        controller.select();
    }//GEN-LAST:event_tablePostoMouseClicked

    private void buttonCombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCombActionPerformed
        if(tablePosto.getSelectedRow() != -1){
            int viewRow = tablePosto.getSelectedRow();
            JFrame comb;
            comb = new CombustivelView(tablePosto.convertRowIndexToModel(viewRow), tableModelPosto.getPostoArray());
            comb.setVisible(true);
        }
    }//GEN-LAST:event_buttonCombActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelImage;
    private javax.swing.JButton buttonAlterar;
    private javax.swing.JButton buttonComb;
    private javax.swing.JButton buttonInserir;
    private javax.swing.JButton buttonLimpar;
    private javax.swing.JButton buttonRemover;
    private javax.swing.JLabel labelAno;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel labelNota;
    private javax.swing.JLabel labelNota1;
    private javax.swing.JLabel labelNota2;
    private javax.swing.JLabel labelNota3;
    private javax.swing.JLabel labelNota4;
    private javax.swing.JLabel labelNota5;
    private javax.swing.JLabel labelSemestre;
    private javax.swing.JScrollPane scrollpaneTable;
    private javax.swing.JTable tablePosto;
    private javax.swing.JTextField textBairro;
    private javax.swing.JTextField textBandeira;
    private javax.swing.JTextField textCep;
    private javax.swing.JTextField textCnpj;
    private javax.swing.JTextField textImagem;
    private javax.swing.JTextField textNome;
    private javax.swing.JTextField textNumero;
    private javax.swing.JTextField textRazaoSocial;
    private javax.swing.JTextField textRua;
    // End of variables declaration//GEN-END:variables




}
