package t10_gui.view;


import t10_gui.controller.CombustivelController;
import t10_gui.model.Combustivel;
import t10_gui.model.Posto;
import t10_gui.model.TableModelCombustivel;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


public class CombustivelView extends javax.swing.JFrame {

    private TableModelCombustivel tableModelCombustivel;
    private CombustivelController controller;
    private final int index;
    
    public CombustivelView(int index, ArrayList<Posto> Posto) {
        initComponents();
        this.index = index;
        tableModelCombustivel = new TableModelCombustivel(index,Posto);
        tableLista.setModel(tableModelCombustivel);
        controller = new CombustivelController(this, tableModelCombustivel);
    }

    public JTable getTableLista() {
        return tableLista;
    }

    public JTextField getTextCombustivel() {
        return textComb;
    }

    public JTextField getTextPreco() {
        return textPreco;
    }
    
   public JTextField getTextData() {
        return textData;
    }
    public void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollpaneTable = new javax.swing.JScrollPane();
        tableLista = new javax.swing.JTable();
        labelNome = new javax.swing.JLabel();
        textData = new javax.swing.JTextField();
        buttonLimpar = new javax.swing.JButton();
        buttonRemover = new javax.swing.JButton();
        buttonInserir = new javax.swing.JButton();
        labelAno = new javax.swing.JLabel();
        labelSemestre = new javax.swing.JLabel();
        buttonAlterar = new javax.swing.JButton();
        textComb = new javax.swing.JTextField();
        textPreco = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tableLista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tableLista.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableLista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableListaMouseClicked(evt);
            }
        });
        scrollpaneTable.setViewportView(tableLista);

        labelNome.setText("Data");

        buttonLimpar.setText("Limpar");
        buttonLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLimparActionPerformed(evt);
            }
        });

        buttonRemover.setText("Remover");
        buttonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonRemoverActionPerformed(evt);
            }
        });

        buttonInserir.setText("Inserir");
        buttonInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonInserirActionPerformed(evt);
            }
        });

        labelAno.setText("Combustivel");

        labelSemestre.setText("Preço");

        buttonAlterar.setText("Alterar");
        buttonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAlterarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(scrollpaneTable, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelSemestre)
                            .addComponent(labelNome)
                            .addComponent(labelAno))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textPreco)
                            .addComponent(textData, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textComb, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(buttonLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(buttonAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(buttonRemover)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(buttonInserir)))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {buttonAlterar, buttonInserir, buttonLimpar, buttonRemover});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelAno)
                    .addComponent(textComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelSemestre)
                    .addComponent(textPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelNome))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonInserir)
                    .addComponent(buttonRemover)
                    .addComponent(buttonAlterar)
                    .addComponent(buttonLimpar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollpaneTable, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonRemoverActionPerformed
        controller.remove();
    }//GEN-LAST:event_buttonRemoverActionPerformed
    
    private void buttonInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonInserirActionPerformed
        controller.insert();
    }//GEN-LAST:event_buttonInserirActionPerformed

    private void buttonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAlterarActionPerformed
        controller.update();
    }//GEN-LAST:event_buttonAlterarActionPerformed

    private void buttonLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLimparActionPerformed
        controller.clear();
    }//GEN-LAST:event_buttonLimparActionPerformed

    private void tableListaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableListaMouseClicked
        controller.select();
    }//GEN-LAST:event_tableListaMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonAlterar;
    private javax.swing.JButton buttonInserir;
    private javax.swing.JButton buttonLimpar;
    private javax.swing.JButton buttonRemover;
    private javax.swing.JLabel labelAno;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel labelSemestre;
    private javax.swing.JScrollPane scrollpaneTable;
    private javax.swing.JTable tableLista;
    private javax.swing.JTextField textComb;
    private javax.swing.JTextField textData;
    private javax.swing.JTextField textPreco;
    // End of variables declaration//GEN-END:variables

    public int getPostoIndex() {
        return index;
    }




}
