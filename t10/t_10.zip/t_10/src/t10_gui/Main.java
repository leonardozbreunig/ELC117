package t10_gui;

import t10_gui.view.PostoView;
import javax.swing.SwingUtilities;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
	    public void run() {
		new PostoView().setVisible(true);
	    }
	});
    }

}
