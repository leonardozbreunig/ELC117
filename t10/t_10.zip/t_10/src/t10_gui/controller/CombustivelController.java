package t10_gui.controller;

import t10_gui.model.Combustivel;
import t10_gui.model.TableModelCombustivel;
import t10_gui.view.CombustivelView;

public class CombustivelController {

    private CombustivelView view;
    private TableModelCombustivel model;

    public CombustivelController(CombustivelView view, TableModelCombustivel model) {
        this.view = view;
        this.model = model;
    }

    public void insert() {
        Combustivel c = newFromView();
        if (c != null) {
            model.add(view.getPostoIndex(), c);
        }
    }

    public void update() {
        int index = view.getTableLista().getSelectedRow();
        if (index == -1) {
            return;
        }
        Combustivel c = newFromView();
        if (c != null) {
            model.update(view.getPostoIndex(), index, c);
        }
    }

    public void remove() {
        int index = view.getTableLista().getSelectedRow();
        if (index == -1) {
            return;
        }
        model.remove(view.getPostoIndex(), index);
    }

    public void select() {
        int i = view.getTableLista().getSelectedRow();
        int index = view.getPostoIndex();
        Combustivel c = model.select(index, i);
        if (index == -1) {
            return;
        }
        view.getTextCombustivel().setText(c.getComb());
        view.getTextData().setText(c.getData());
        view.getTextPreco().setText(c.getPreço());
    }

    public void clear() {
        view.getTextCombustivel().setText("");
        view.getTextData().setText("");
        view.getTextPreco().setText("");
    }

    private Combustivel newFromView() {
        try {
            Combustivel c = new Combustivel();
            c.setComb(view.getTextCombustivel().getText());
            c.setData(view.getTextData().getText());
            c.setPreço(view.getTextPreco().getText());
            return c;
        } catch (NumberFormatException e) {
            view.showError("Dado(s) de entrada invalido(s)!");
            return null;
        }
    }
}
