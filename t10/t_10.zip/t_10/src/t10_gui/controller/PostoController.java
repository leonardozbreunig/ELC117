
package t10_gui.controller;

import t10_gui.model.Posto;
import t10_gui.model.TableModelPosto;
import t10_gui.view.PostoView;
import java.awt.Image;
import javax.swing.ImageIcon;

public class PostoController {

    private PostoView view;
    private TableModelPosto model;

    public PostoController(PostoView view, TableModelPosto model) {
        this.view = view;
        this.model = model;
    }

    public void insert() {
        Posto posto = newFromView();
        if (posto != null) {
            model.add(posto);
        }
    }

    public void update() {
        int index = view.getTablePosto().getSelectedRow();
        if (index == -1) {
            return;
        }
        Posto posto = newFromView();
        if (posto != null) {
            model.update(index, posto);
        }
    }

    public void remove() {
        int index = view.getTablePosto().getSelectedRow();
        if (index == -1) {
            return;
        }
        model.remove(index);
    }

    public void select() {
        int index = view.getTablePosto().getSelectedRow();
        if (index == -1) {
            return;
        }
        Posto posto = model.select(index);
        ImageIcon imageIcon = new ImageIcon(posto.getImagem());
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        view.getTextCnpj().setText(posto.getCnpj());
        view.getTextRazaoSocial().setText(posto.getRazao_social());
        view.getTextNome().setText(posto.getNome_fantasia());
        view.getTextBandeira().setText(posto.getBandeira());
        view.getTextRua().setText(posto.getRua());
        view.getTextNumero().setText(posto.getNumero());
        view.getTextBairro().setText(posto.getBairro());
        view.getTextCep().setText(posto.getCep());
        view.getTextImagem().setText(posto.getImagem());
    }

    public void clear() {
        view.getTextCnpj().setText("");
        view.getTextRazaoSocial().setText("");
        view.getTextNome().setText("");
        view.getTextBandeira().setText("");
        view.getTextRua().setText("");
        view.getTextNumero().setText("");
        view.getTextBairro().setText("");
        view.getTextCep().setText("");
        view.getTextImagem().setText("");
    }

    private Posto newFromView() {
        try {
            Posto p = new Posto();
            p.setCnpj(view.getTextCnpj().getText());
            p.setRazao_social(view.getTextRazaoSocial().getText());
            p.setNome_fantasia(view.getTextNome().getText());
            p.setBandeira(view.getTextBandeira().getText());
            p.setRua(view.getTextRua().getText());
            p.setNumero(view.getTextRua().getText());
            p.setBairro(view.getTextBairro().getText());
            p.setCep(view.getTextCep().getText());
            p.setImagem(view.getTextImagem().getText());
            return p;
        } catch (NumberFormatException e) {
            view.showError("Dado(s) de entrada invalido(s)!");
            return null;
        }
    }
}
